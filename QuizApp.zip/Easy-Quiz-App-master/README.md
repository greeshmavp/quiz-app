# Easy-Quiz-App

![image](https://user-images.githubusercontent.com/108933534/215812414-8ffb0156-8332-4779-8fb3-adb1594107c3.png)

