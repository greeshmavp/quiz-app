package com.azamovhudstc.quizapp.presenter;

import com.azamovhudstc.quizapp.contract.MainContract;

public class MainPresenter implements MainContract.MainPresenter {
}
