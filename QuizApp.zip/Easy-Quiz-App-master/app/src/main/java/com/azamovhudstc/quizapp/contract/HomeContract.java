package com.azamovhudstc.quizapp.contract;

public interface HomeContract  {
    interface HomeModel{

    }
    interface HomePresenter{

    }
    interface HomeView{}
}

