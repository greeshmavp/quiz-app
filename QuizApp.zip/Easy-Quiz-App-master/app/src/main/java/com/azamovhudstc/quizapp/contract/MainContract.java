package com.azamovhudstc.quizapp.contract;

public interface MainContract {

    interface MainModel{

    }
    interface MainView{

    }
    interface MainPresenter{

    }
}
