package com.azamovhudstc.quizapp.model;

public class MathModel {
}
