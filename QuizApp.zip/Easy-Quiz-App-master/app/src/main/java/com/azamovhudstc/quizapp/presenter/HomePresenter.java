package com.azamovhudstc.quizapp.presenter;


import com.azamovhudstc.quizapp.contract.HomeContract;

public class HomePresenter implements HomeContract.HomePresenter {
}
